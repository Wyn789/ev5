import { Router } from "express";
import Estudiante from "../models/Estudiante.js";

const router = Router();

router.post("/insertar", async (req, res) => {
  try {
    const nuevo = await Estudiante.create(req.body);
    res.status(201).json(nuevo);
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
});

router.put("/actualizar/:id", async (req, res) => {
  try {
    const actualizado = await Estudiante.findOneAndUpdate(
      { rut: req.params.id }, req.body, { new: true, runValidators: true }
    );
    if (!actualizado) return res.status(404).json({ message: "No encontrado" });
    res.json(actualizado);
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
});

router.get("/buscar/:id", async (req, res) => {
  const doc = await Estudiante.findOne({ rut: req.params.id });
  if (!doc) return res.status(404).json({ message: "No encontrado" });
  res.json(doc);
});

router.delete("/borrar/:id", async (req, res) => {
  const doc = await Estudiante.findOneAndDelete({ rut: req.params.id });
  if (!doc) return res.status(404).json({ message: "No encontrado" });
  res.json(doc);
});

export default router;
