import express from "express";
import cors from "cors";
import morgan from "morgan";
import mongoose from "mongoose";
import dotenv from "dotenv";
import path from "path";
import estudianteRoutes from "./routes/estudiantes.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(morgan("dev"));
app.use(express.json());

// API REST
app.use("/api", estudianteRoutes);

// Servir frontend (opcional)
app.use(express.static(path.resolve("../frontend")));

// Mongo & servidor
const PORT = process.env.PORT || 4000;
mongoose.connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, () => console.log("API escuchando en puerto", PORT)))
  .catch(err => console.error("Error al conectar Mongo:", err));
