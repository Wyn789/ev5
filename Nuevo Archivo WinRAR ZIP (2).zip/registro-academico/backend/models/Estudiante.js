import mongoose from "mongoose";

const EstudianteSchema = new mongoose.Schema({
  fecha:       { type: String, required: true },
  rut:         { type: String, required: true, unique: true },
  apellidos:   String,
  nombres:     String,
  correo:      String,
  calificacion:Number,
  nota:        Number,
  evaluacion:  String,
  asignatura:  String,
  curso:       String
}, { versionKey: false });

export default mongoose.model("Estudiante", EstudianteSchema);
