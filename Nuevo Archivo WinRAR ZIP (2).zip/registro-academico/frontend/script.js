//  ---- Frontend ES‑Module ----
const $ = (id) => document.getElementById(id);
const api = "/api";

$("calificacion").addEventListener("input", calcularNota);
$("registroForm").addEventListener("submit", insertarEstudiante);
$("btnActualizar").addEventListener("click", actualizarEstudiante);
$("btnBuscar")   .addEventListener("click", buscarEstudiante);
$("btnBorrar")   .addEventListener("click", borrarEstudiante);

// --------- Cálculo de nota 7‑1 basado en % de exigencia ----------
function calcularNota () {
  const max = 100, exigencia = 60, nMin = 1, nMax = 7, nAprob = 4;
  const calif = parseFloat($("calificacion").value);
  if (isNaN(calif) || calif < 0 || calif > max) return $("nota").value = "";
  const ex = max * (exigencia/100);
  const nota = calif >= ex
      ? nAprob + ((calif - ex) * (nMax - nAprob)) / (max - ex)
      : nMin   + (calif            * (nAprob - nMin)) / ex;
  $("nota").value = (Math.round(Math.max(nMin,Math.min(nMax,nota))*10)/10).toFixed(1);
}

// -------------------- CRUD --------------------
async function insertarEstudiante(e){
  e.preventDefault();
  const estudiante = obtenerDatosFormulario();
  if(!estudiante) return;
  await enviarFetch(`${api}/insertar`, "POST", estudiante, "Insertado correctamente");
}

async function actualizarEstudiante(){
  const estudiante = obtenerDatosFormulario();
  if(!estudiante) return;
  await enviarFetch(`${api}/actualizar/${estudiante.rut}`, "PUT", estudiante, "Actualizado correctamente");
}

async function buscarEstudiante(){
  const rut = $("rut").value.trim();
  if(!validarRUT(rut)) return alerta("RUT inválido", true);
  try{
    const res = await fetch(`${api}/buscar/${rut}`);
    const data = await res.json();
    if(!res.ok) throw new Error(data.message || res.statusText);
    alerta("Documento encontrado:", false, data);
    llenarFormulario(data);
  }catch(err){alerta(err.message,true);}
}

async function borrarEstudiante(){
  const rut = $("rut").value.trim();
  if(!validarRUT(rut)) return alerta("RUT inválido", true);
  await enviarFetch(`${api}/borrar/${rut}`, "DELETE", null, "Eliminado correctamente");
}

async function enviarFetch(url, method, body, okMsg){
  try{
    const res = await fetch(url,{method,headers:{'Content-Type':'application/json'},body: body && JSON.stringify(body)});
    const data = await res.json();
    if(!res.ok) throw new Error(data.message || res.statusText);
    alerta(okMsg, false, data);
    if(method !=="GET") $("registroForm").reset();
  }catch(err){alerta(err.message,true);}
}

// -------- utilidades ----------
function alerta(msg, esError=false, datos=null){
  $("resultado").className = esError? "error":"success";
  $("resultado").textContent = msg + (datos? "\n"+JSON.stringify(datos,null,2):"");
}

function llenarFormulario(d){
  ["fecha","rut","apellidos","nombres","correo",
   "calificacion","nota","evaluacion","asignatura","curso"]
   .forEach(k=> $(k).value = d?.[k] ?? "");
}

function obtenerDatosFormulario(){
  const fecha = $("fecha").value;
  const rut   = $("rut").value.trim();
  if(!validarFecha(fecha)){alerta("La fecha no puede ser futura",true);return;}
  if(!validarRUT(rut)){alerta("RUT inválido",true);return;}
  if(!$("registroForm").reportValidity()) return; // HTML5 pattern/email/required
  return {
    fecha,rut,
    apellidos:$("apellidos").value.trim(),
    nombres:  $("nombres").value.trim(),
    correo:   $("correo").value.trim(),
    calificacion:+$("calificacion").value,
    nota:+$("nota").value||null,
    evaluacion:$("evaluacion").value.trim(),
    asignatura:$("asignatura").value.trim(),
    curso:$("curso").value.trim()
  };
}

// --- Validaciones extra ---
function validarFecha(f){return f <= new Date().toISOString().split("T")[0];}

function validarRUT(rut){
  rut = rut.replace(/\./g,"").replace(/-/,"");
  if(rut.length<2) return false;
  const cuerpo = rut.slice(0,-1), dv = rut.slice(-1).toUpperCase();
  let sum=0,m=2;
  for(let i=cuerpo.length-1;i>=0;i--){
    sum += +cuerpo[i]*m;
    m = m<7? m+1:2;
  }
  const res = 11 - (sum%11);
  const dvCalc = res===11?"0":res===10?"K":res.toString();
  return dv===dvCalc;
}
